#!/usr/bin/env bash
# Runs as `node`. Copies your host Pi setup (mounted read-only under /host)
# into the container's home volume, so the container can never write back to it.
# auth.json, trust.json and sessions are never brought in from the host.
set -euo pipefail

HOST_DIR=/host/pi
AGENT_DIR="${PI_CODING_AGENT_DIR:-$HOME/.pi/agent}"
mkdir -p "$AGENT_DIR"

# ---- ~/.pi/agent: host is the source of truth, re-synced every start --------
for f in settings.json keybindings.json models.json \
         AGENTS.override.md AGENTS.md AGENTS.MD CLAUDE.md CLAUDE.MD \
         SYSTEM.md APPEND_SYSTEM.md mcp.json; do
  if [[ -f "$HOST_DIR/$f" ]]; then
    install -m 0644 "$HOST_DIR/$f" "$AGENT_DIR/$f"
  fi
done

for d in extensions skills prompts themes; do
  if [[ -d "$HOST_DIR/$d" ]]; then
    rm -rf "${AGENT_DIR:?}/$d"
    cp -R "$HOST_DIR/$d" "$AGENT_DIR/$d"
  fi
done

# ---- git ---------------------------------------------------------------------
if [[ -f /host/gitconfig ]]; then
  cp /host/gitconfig "$HOME/.gitconfig"
  # Host helpers (osxkeychain, manager-core) don't exist here
  git config --global --unset-all credential.helper 2>/dev/null || true
  # Signing only works if an SSH agent was forwarded
  if [[ -z "${SSH_AUTH_SOCK:-}" ]]; then
    git config --global commit.gpgsign false
    git config --global tag.gpgsign false
  fi
fi

if ! git config --global --get-all safe.directory 2>/dev/null | grep -qx '/workspace'; then
  git config --global --add safe.directory /workspace
fi

if [[ -n "${GH_TOKEN:-}" ]]; then
  gh auth setup-git >/dev/null 2>&1 || true
fi

exec "$@"
