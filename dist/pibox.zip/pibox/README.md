# pibox

Run the [Pi coding agent](https://pi.dev) against any project in a locked-down container. It uses the same isolation as ccbox and brings your own Pi setup: `settings.json`, `models.json`, `AGENTS.md`/`SYSTEM.md`, keybindings, extensions, skills, prompts, themes and git identity.

Pi runs tool calls without asking, and its project-trust prompt only decides which project resources load; it doesn't limit what tools can access. Pi's own security guide recommends a container for exactly that reason.

## Install

```bash
unzip pibox.zip -d ~/.local/share
ln -s ~/.local/share/pibox/pibox ~/.local/bin/pibox
chmod +x ~/.local/share/pibox/pibox
pibox build                                   # PI_VERSION=x.y.z pibox build to pin
```

## Auth (pick one or more)

1. **API keys from Keychain (macOS).** Store each key under service `pibox`, with the variable name as the account:
   ```bash
   security add-generic-password -s pibox -a ANTHROPIC_API_KEY -w '<key>'
   security add-generic-password -s pibox -a OPENAI_API_KEY    -w '<key>'
   ```
2. **API keys from your environment.** Any supported key variable already set in your shell is passed in (see the `keys` list in `pibox`).
3. **Claude Pro/Max.** If you set up ccbox's Keychain token (`claude setup-token`), pibox reuses it as `ANTHROPIC_OAUTH_TOKEN`. Nothing else to do.
4. **`/login` inside the box.** First uncomment that provider's login domains in `allowlist.txt` and rebuild (or use `PIBOX_ALLOW`). The OAuth redirect can't reach the container, so paste the final redirect URL or code back into Pi when it asks. Credentials are saved to `auth.json` in the `pibox-home` volume.

Your host's `auth.json`, `trust.json` and sessions are **never** mounted.

## Usage

```bash
cd ~/code/my-app
pibox                        # pi
pibox -p 'explain src/'      # args pass straight through to pi
pibox --model <id>           # any pi flag works
pibox shell                  # bash in the box
PIBOX_PORTS=3000 pibox       # next dev on 127.0.0.1:3000 (run it with -H 0.0.0.0)
pibox reset                  # wipe the home volume: logins, sessions, installed packages
```

`pi install npm:…` / `git:…` works inside the box, and packages persist in the volume. Packages declared in your host `settings.json` are installed in the box the same way.

## Options (env vars)

| Var | Default | Effect |
|---|---|---|
| `PIBOX_ALLOW` | — | Extra outbound domains, comma-separated: `api.groq.com,api.x.ai` |
| `PIBOX_PORTS` | — | Ports to publish on localhost only |
| `PIBOX_GH=1` | off | Passes `gh auth token` in as `GH_TOKEN` |
| `PIBOX_SSH=1` | off | Forwards your SSH agent |
| `PIBOX_MCP=1` | off | Syncs `~/.pi/agent/mcp.json` (it can contain tokens) |
| `PIBOX_MASK_EXTRA` | — | Extra file names to mask, comma-separated: `*.p12,secrets.json` |
| `PIBOX_MASK=off` | on | Turns off secret-file masking |
| `PIBOX_FIREWALL=on` | off | Restricts outbound traffic to the allowlist |
| `PIBOX_MEMORY` / `PIBOX_CPUS` / `PIBOX_PIDS` | 8g / 4 / 2048 | Resource limits |

To replace the built-in allowlist permanently, put your own at `~/.config/pibox/allowlist.txt`. The default enables Anthropic, OpenAI, Google Gemini and OpenRouter; uncomment others in `allowlist.txt`.

## Differences from ccbox

- **Many providers.** Pi talks to whichever model provider you pick, so the allowlist has a provider section, and the launcher passes in every supported key it finds.
- **No `--yolo`.** Pi has no permission prompts to skip.
- **No phoning home.** `PI_SKIP_VERSION_CHECK=1` and `PI_TELEMETRY=0` are set, and `pi.dev` isn't on the allowlist used when the firewall is on. `pi update` won't work because the root filesystem is read-only. Rebuild with `pibox build` to update.
- **Copy works.** `PI_CLIPBOARD_OSC52=1` sends copied text through your terminal (iTerm2, Ghostty, kitty and WezTerm support it).
- **Installed with `--ignore-scripts`**, as Pi's containerization guide recommends.

## Secret files are masked

At startup the launcher covers these files in your project with an empty, read-only file: `.env`, `.env.*`, `.dev.vars`, `*.pem` and `*.key`. It skips `.env.example`, `.env.sample` and `.env.template`, and doesn't look inside `node_modules`, `.git`, `.next` or `dist`. Inside the box the agent sees those files as empty and can't write to them. Your real files are untouched.

What masking doesn't cover:
- **Dev servers in the box start without your env vars.** Pass the ones you need with `-e`, or run the dev server on your Mac.
- **Git history.** Anything ever committed can still be read with `git log -p`.
- **Secrets in other files,** such as config files or `.npmrc`. Add those names to `PIBOX_MASK_EXTRA`.
- **Files created after the box starts** aren't masked.

## What's isolated / what isn't

The same as ccbox:
- **Isolated:** only `$PWD` is writable, secret files are masked, and the box runs as a non-root user with no capabilities or sudo. Outbound traffic is open by default; set `PIBOX_FIREWALL=on` to restrict it to the allowlist.
- **Not isolated:** your project folder is fully writable, and with the network open, Pi can send anything in it (other than masked files) anywhere. Every key you pass in is visible to commands Pi runs, so pass in only the providers you use. Even with the firewall on, DNS tunnelling is still possible, and the box shares the kernel with Docker's VM.
- **Pi-specific:** extensions and packages run inside the Pi process with the same access as Pi. Review them before installing, as Pi's docs advise.
