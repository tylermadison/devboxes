# ccbox

Run Claude Code against any project in a locked-down container. It still picks up your own setup: `CLAUDE.md`, `settings.json`, agents, commands, skills and git identity.

## Install

```bash
git clone <this> ~/.local/share/ccbox        # or unzip here
ln -s ~/.local/share/ccbox/ccbox ~/.local/bin/ccbox
chmod +x ~/.local/share/ccbox/ccbox
ccbox build                                  # CLAUDE_CODE_VERSION=x.y.z ccbox build to pin
```

## Auth (pick one)

1. **Login once inside the box.** Run `ccbox`, then `/login`, and open the URL on your host. The login is saved in the `ccbox-home` volume.
2. **Long-lived token in Keychain (macOS).**
   ```bash
   claude setup-token                                   # on host
   security add-generic-password -s ccbox -a "$USER" -w '<token>'
   ```
   `ccbox` reads it automatically and passes it in as `CLAUDE_CODE_OAUTH_TOKEN`.
3. **Use the `ANTHROPIC_API_KEY` env var.** If it is set, ccbox passes it through.

Your host's Claude credentials are **never** mounted.

## Usage

```bash
cd ~/code/my-app
ccbox                       # claude
ccbox --yolo                # claude --dangerously-skip-permissions (this is what the box is for)
ccbox -p 'explain src/'     # args pass through to claude
ccbox shell                 # bash in the box
CCBOX_PORTS=3000 ccbox      # expose next dev on 127.0.0.1:3000 (run it with -H 0.0.0.0)
ccbox reset                 # wipe the home volume (history, login, caches)
```

## Options (env vars)

| Var | Default | Effect |
|---|---|---|
| `CCBOX_ALLOW` | — | Extra egress domains, comma-separated: `vercel.com,api.neon.tech` |
| `CCBOX_PORTS` | — | Ports to publish to localhost only |
| `CCBOX_GH=1` | off | Passes `gh auth token` in as `GH_TOKEN` (enables `gh` + HTTPS git push) |
| `CCBOX_SSH=1` | off | Forwards your SSH agent (Docker Desktop socket on macOS) |
| `CCBOX_MCP=1` | off | Syncs user-scoped `mcpServers` from `~/.claude.json` |
| `CCBOX_MASK_EXTRA` | — | Extra file names to mask, comma-separated: `*.p12,secrets.json` |
| `CCBOX_MASK=off` | on | Turns off secret-file masking |
| `CCBOX_FIREWALL=on` | off | Restricts outbound traffic to the allowlist |
| `CCBOX_MEMORY` / `CCBOX_CPUS` / `CCBOX_PIDS` | 8g / 4 / 2048 | Resource ceilings |

To replace the built-in allowlist permanently, put your own at `~/.config/ccbox/allowlist.txt`.

## Secret files are masked

At startup the launcher covers these files in your project with an empty, read-only file: `.env`, `.env.*`, `.dev.vars`, `*.pem` and `*.key`. It skips `.env.example`, `.env.sample` and `.env.template`, and doesn't look inside `node_modules`, `.git`, `.next` or `dist`. Inside the box the agent sees those files as empty and can't write to them. Your real files are untouched.

What masking doesn't cover:
- **Dev servers in the box start without your env vars.** Pass the ones you need with `-e`, or run the dev server on your Mac.
- **Git history.** Anything ever committed can still be read with `git log -p`.
- **Secrets in other files,** such as config files or `.npmrc`. Add those names to `CCBOX_MASK_EXTRA`.
- **Files created after the box starts** aren't masked.

## What's isolated

- **Filesystem:** only `$PWD` is writable, at `/workspace`. Your host config is mounted read-only, item by item, and *copied* into the container. Nothing Claude does can change your `~/.claude`, `~/.gitconfig` or anything else in `$HOME`. The root filesystem is read-only.
- **Network (opt-in):** the network is open by default. With `CCBOX_FIREWALL=on`, outbound traffic is denied (iptables + ipset) except to allowlisted domains, GitHub CIDRs and Docker's DNS, and all IPv6 egress is blocked. The container then refuses to start if the firewall check fails.
- **Privileges:** the box starts as root only to set up the firewall (when it's on). It then drops to `node` with no capabilities and `no-new-privs`. There is no sudo, so Claude can't undo the firewall.
- **Secrets:** no `~/.ssh`, cloud CLI configs, keychains, `.env` files from other projects, or Docker socket.
- **Resources:** memory, CPU and PID limits stop runaway processes.

## What isn't

- **Your project is fully writable.** Commit before `--yolo` runs. Secret files are masked, but anything else in the project can be sent anywhere unless the firewall is on.
- **DNS:** queries go through Docker's resolver, so DNS-tunnel exfiltration is still theoretically possible.
- **IPs are resolved once at startup.** If a CDN rotates IPs during a long session, restart the box.
- **Opt-ins widen exposure.** `CCBOX_GH` gives the box your GitHub scopes. `CCBOX_SSH` lets it sign with your keys while it runs.
- **MCP servers and hooks** that point at host-only paths or binaries won't work in the box. `npx`/`bunx`-based servers will, as long as their domains are allowlisted when the firewall is on.
- **Plugins** under `~/.claude/plugins` aren't synced, because their manifests contain host paths. Install them inside the box instead; they persist in the volume.
- **It's a container, not a VM.** It shares the kernel. On macOS, Docker Desktop's Linux VM adds a second boundary.
