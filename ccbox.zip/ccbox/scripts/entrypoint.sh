#!/usr/bin/env bash
# Runs as root: install egress firewall, then permanently drop to `node`.
set -euo pipefail

if [[ "$(id -u)" != '0' ]]; then
  exec /usr/local/bin/ccbox-user-init "$@"
fi

if [[ "${CCBOX_FIREWALL:-on}" == 'off' ]]; then
  echo '[ccbox] network: open (CCBOX_FIREWALL=on to restrict to the allowlist)' >&2
else
  /usr/local/bin/ccbox-firewall
fi

# Drop to node: uid change clears permitted/effective caps, inheritable caps are
# cleared explicitly, and no-new-privs blocks regaining anything via setuid/file caps.
exec setpriv \
  --reuid=node --regid=node --init-groups \
  --inh-caps=-all \
  --no-new-privs \
  env HOME=/home/node USER=node LOGNAME=node \
  /usr/bin/tini -g -- /usr/local/bin/ccbox-user-init "$@"
# tini runs as PID 1 *after* the drop, with the same uid as everything it
# supervises, so it can forward signals without CAP_KILL.
