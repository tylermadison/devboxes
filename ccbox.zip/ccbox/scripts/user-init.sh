#!/usr/bin/env bash
# Runs as `node`. Copies your host Claude setup (mounted read-only under /host)
# into the container's home volume, so the container can never write back to it.
set -euo pipefail

HOST_DIR=/host
mkdir -p "$HOME/.claude"

# ---- ~/.claude: host is the source of truth, re-synced every start ---------
for f in CLAUDE.md settings.json; do
  if [[ -f "$HOST_DIR/claude/$f" ]]; then
    install -m 0644 "$HOST_DIR/claude/$f" "$HOME/.claude/$f"
  fi
done

for d in agents commands skills output-styles; do
  if [[ -d "$HOST_DIR/claude/$d" ]]; then
    rm -rf "${HOME:?}/.claude/$d"
    cp -R "$HOST_DIR/claude/$d" "$HOME/.claude/$d"
  fi
done

# ---- user-scoped MCP servers (opt-in: CCBOX_MCP=1) --------------------------
if [[ -f "$HOST_DIR/claude.json" ]]; then
  target="$HOME/.claude.json"
  [[ -f "$target" ]] || echo '{}' > "$target"
  tmp="$(mktemp)"
  jq --slurpfile host "$HOST_DIR/claude.json" \
     '.mcpServers = ($host[0].mcpServers // {})' "$target" > "$tmp"
  mv "$tmp" "$target"
fi

# ---- git ---------------------------------------------------------------------
if [[ -f "$HOST_DIR/gitconfig" ]]; then
  cp "$HOST_DIR/gitconfig" "$HOME/.gitconfig"
  # Host helpers (osxkeychain, manager-core) don't exist here
  git config --global --unset-all credential.helper 2>/dev/null || true
  # Signing only works if an SSH agent was forwarded
  if [[ -z "${SSH_AUTH_SOCK:-}" ]]; then
    git config --global commit.gpgsign false
    git config --global tag.gpgsign false
  fi
fi

if ! git config --global --get-all safe.directory 2>/dev/null | grep -qx '/workspace'; then
  git config --global --add safe.directory /workspace
fi

if [[ -n "${GH_TOKEN:-}" ]]; then
  gh auth setup-git >/dev/null 2>&1 || true
fi

exec "$@"
