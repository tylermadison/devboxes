#!/usr/bin/env bash
# Default-deny egress. Only allowlisted domains, GitHub CIDRs and the container's
# DNS resolver are reachable. Fails closed: any error aborts container start.
set -euo pipefail

SET=ccbox-allow
ALLOWLIST_FILE=/etc/ccbox/allowlist.txt
log() { echo "[ccbox-fw] $*" >&2; }

ipset destroy "$SET" 2>/dev/null || true
ipset create "$SET" hash:net family inet hashsize 4096 maxelem 65536

# ---- collect domains -------------------------------------------------------
domains=()
while IFS= read -r line || [[ -n "$line" ]]; do
  line="${line%%#*}"
  line="$(echo "$line" | xargs)"
  [[ -n "$line" ]] && domains+=("$line")
done < "$ALLOWLIST_FILE"

if [[ -n "${CCBOX_ALLOW:-}" ]]; then
  IFS=',' read -ra extra <<< "$CCBOX_ALLOW"
  for d in "${extra[@]}"; do
    d="$(echo "$d" | xargs)"
    [[ -n "$d" ]] && domains+=("$d")
  done
fi

# ---- GitHub CIDRs (fetched before rules are applied) -----------------------
if meta="$(curl -fsS --max-time 10 https://api.github.com/meta)"; then
  count=0
  while read -r cidr; do
    ipset add -exist "$SET" "$cidr"
    count=$((count + 1))
  done < <(echo "$meta" | jq -r '(.web + .api + .git)[]' | grep -v ':')
  log "github: $count CIDRs"
else
  log 'warn: could not fetch GitHub meta; github.com will be resolved by DNS only'
  domains+=('github.com' 'api.github.com')
fi

# ---- resolve allowlisted domains -------------------------------------------
BOX_TAG=ccbox
pins=''
for d in "${domains[@]}"; do
  ips="$(dig +short +time=3 +tries=2 A "$d" | grep -E '^[0-9]+(\.[0-9]+){3}$' || true)"
  if [[ -z "$ips" ]]; then
    log "warn: $d did not resolve, skipping"
    continue
  fi
  while read -r ip; do
    ipset add -exist "$SET" "$ip"
    pins+="$ip $d"$'\n'
  done <<< "$ips"
done
log "allowlisted ${#domains[@]} domains"

# Pin allowlisted names to the IPs we just allowed. CDN-fronted APIs hand out
# different IPs per lookup; without this the agent can resolve an IP that isn't
# in the set and fail with EHOSTUNREACH.
if [[ -n "$pins" && -w /etc/hosts ]]; then
  { echo "# $BOX_TAG pinned"; printf '%s' "$pins"; } >> /etc/hosts
else
  log 'warn: could not pin IPs in /etc/hosts; CDN IP rotation may cause connection errors'
fi

# ---- IPv4 rules ------------------------------------------------------------
iptables -F OUTPUT
iptables -A OUTPUT -o lo -j ACCEPT
iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# DNS only to the configured resolver(s) (Docker's embedded DNS is 127.0.0.11 on lo)
while read -r ns; do
  iptables -A OUTPUT -p udp -d "$ns" --dport 53 -j ACCEPT
  iptables -A OUTPUT -p tcp -d "$ns" --dport 53 -j ACCEPT
done < <(awk '/^nameserver/ {print $2}' /etc/resolv.conf | grep -v ':')

iptables -A OUTPUT -m set --match-set "$SET" dst -j ACCEPT
iptables -A OUTPUT -j REJECT --reject-with icmp-admin-prohibited

# ---- IPv6: block all egress ------------------------------------------------
if ip6tables -L OUTPUT >/dev/null 2>&1; then
  ip6tables -F OUTPUT
  ip6tables -A OUTPUT -o lo -j ACCEPT
  ip6tables -A OUTPUT -j REJECT
fi

# ---- verify ----------------------------------------------------------------
if curl -fsS --max-time 5 -o /dev/null https://example.com 2>/dev/null; then
  log 'FATAL: example.com is reachable — firewall not effective'
  exit 1
fi
code="$(curl -s --max-time 8 -o /dev/null -w '%{http_code}' https://api.anthropic.com || true)"
if [[ "$code" == '000' ]]; then
  log 'warn: api.anthropic.com unreachable — Claude Code will not work'
else
  log 'ok: egress locked to allowlist'
fi
